# -*- coding: utf-8 -*-
import scrapy
import pymongo

class DemoSpider(scrapy.Spider):
    name = 'demo'
    allowed_domains = ['exercise.kingname.info']
    start_urls = ['https://guba.eastmoney.com/']

    def parse(self, response):
        item_list = response.xpath('//ul[@class="newlist"]')

        for item in item_list:
            url_list = item.xpath('li/span/a[2]/@href').extract()
            title_list = item.xpath('li/span/a[2]/text()').extract()

        d = dict(zip(title_list, url_list))
        print(d)
        # for url in url_list:
        #     u = 'https://guba.eastmoney.com' + url
