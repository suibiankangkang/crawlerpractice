# -*- coding: utf-8 -*-
import scrapy


class ExampleSpider(scrapy.Spider):
    name = 'example'
    allowed_domains = ['example.com']
    start_urls = ['http://exercise.kingname.info/exercise_xpath_2.html']

    def parse(self, response):
        items = response.xpath('//ul[@class="item"]')
        for item in items:
            name = item.xpath('li[@class="name"]/text()').extract()
            price = item.xpath('li[@class="price"]/text()').extract()
            name = name[0] if name else 'N/A'
            price = price[0] if price else 'N/A'
            print(name+'---------->'+price)